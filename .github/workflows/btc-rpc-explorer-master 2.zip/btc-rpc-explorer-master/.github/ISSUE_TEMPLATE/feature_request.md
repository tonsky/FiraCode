---
name: Feature request
about: Request a new feature/enhancement be added
title: ''
labels: enhancement
assignees: ''

---

**Describe the new feature or enhancement**

A clear description of the new feature or enhancement. Perhaps a description of how it functions, how it looks, where it "lives", etc.


**Additional context**

Add any other context about the value of the new feature.
